export default {
    back: "back"
}