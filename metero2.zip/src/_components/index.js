import Header from '../_components/_UICompoents/Header';
import Footer from '../_components/_UICompoents/Footer';
import UserProfile from './_UICompoents/UserProfile';
import HeaderBottom from './_UICompoents/HeaderBottom';
import SplashScreen from './_UICompoents/SplashScreen';


export{
    Header,
    HeaderBottom,
    UserProfile,
    Footer,
    SplashScreen
    
}