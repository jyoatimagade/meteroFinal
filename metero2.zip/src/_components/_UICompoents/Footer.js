import React, {} from 'react';

const Footer = props => {
  return(
    <>
    <div className='footer py-1'>
            <p className="text-center">&#169; 2021 - All Rights with IEA. Developed by IEA Dev Team</p>
    </div>
    </>
        )
}
export default Footer;