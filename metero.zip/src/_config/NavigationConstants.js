export * from './ApiConstants'
export default {
    hug: "HUB"
}