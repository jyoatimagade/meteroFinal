export const API_ENDPOINT = 'https://testmeteroapi.iea.net:60000/api' // Server API
// export const AUTH_HEADERS = { 'X-Authorization': '7fa88a29503ff00b31359e83dc4540bb11e3360f', 'Content-Type': 'application/json' };
export const AUTH_HEADERS = { 'Content-Type': 'application/json' };