import Header from '../_components/_UICompoents/Header';
import Footer from '../_components/_UICompoents/Footer';
import UserProfile from './_UICompoents/UserProfile';
import HeaderBottom from './_UICompoents/HeaderBottom';
import SplashScreen from './_UICompoents/SplashScreen';
// import  keepTheme from './_UICompoents/_toggleThame/theme'
// import setTheme from './_UICompoents/_toggleThame/theme'

export{
    Header,
    HeaderBottom,
    UserProfile,
    Footer,
    SplashScreen,
    // keepTheme,
    // setTheme
    
}