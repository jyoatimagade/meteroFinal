export const LOGIN_REQUEST = "LOGIN_REQUEST";
export const LOGIN_RECEIVE = "LOGIN_RECEIVE";
export const LOGIN_FAILURE = "LOGIN_FAILURE";
export const RESET_LOGIN = "RESET_LOGIN";

